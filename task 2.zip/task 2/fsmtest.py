import socket
import time
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind((socket.gethostname(),1024))
s.listen(2)
listup= []
listdown = []
lis = []
head_size = 10
conn,addr = s.accept()

while True:
		msg = conn.recv(head_size)
		length  = int(msg.decode("utf-8"))
		full_msg = ""
		while(len(full_msg)!=length):
			part = conn.recv(1).decode("utf-8")
			full_msg += part
		if(full_msg=="exit"):
			break
		else:
			lis.append(full_msg)
			print(lis)
			li = full_msg.split(' ')
			if(li[1]=='U'):
				listup.append(int(li[0]))
				listup.append(int(li[2]))
			if(li[1]=='D'):
				listdown.append(int(li[0]))
				listdown.append(int(li[2]))
		time.sleep(1)
