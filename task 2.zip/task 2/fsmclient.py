import socket
import sys
import select
import pickle

client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect((socket.gethostname(),1028))

print("Enter your inputs : \n")
msg = ""
while(msg!="exit"):

	msg = input()
	full_msg = f"{len(msg):<10}"+msg
	client.send(bytes(full_msg.encode("utf-8")))
