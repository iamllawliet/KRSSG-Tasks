import time
import schedule
import threading

def pr():
	while True:

		print("Hello World \n")
		time.sleep(1)

threading.Thread(target = lambda: pr()).start()
print("World")
