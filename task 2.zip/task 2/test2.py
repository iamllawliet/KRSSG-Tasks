hello = input()
print(hello)
