import socket
import sys
import select
import pickle

client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

client.connect((socket.gethostname(),1024))
print("Connected to server ..")
print("Sir, How many numbers do you want to add ???")
m = input()


print("Enter your numbers : ")

full_ar = ""

for i in range(int(m)):
	temp = input()
	full_ar += temp+" "


full_ar = f"{len(full_ar):<10}"+full_ar
print(full_ar)

client.send(bytes(full_ar.encode("utf-8")))
s = int(client.recv(10).decode("utf-8"))

print("THE SUM OF ALL THE NUMBERS IS : {}".format(s))
client.close()
