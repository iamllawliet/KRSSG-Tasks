import socket
import time	

mini = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
mini.connect((socket.gethostname(),1024))
while True:

	
	try:

		full_msg = ""
		head_size = 10
		while True:
	
			msg = mini.recv(head_size)
			print(msg.decode("utf-8"))
			length  = int(msg.decode("utf-8"))
		
			while(len(full_msg)!=length):
				part = mini.recv(1).decode("utf-8")
				full_msg += part
			break
		full_msg += ' '
		print(full_msg)
		partsum = 0
		count = 0
		temp = ""
		for x in full_msg:
			if(x!=' '):
				temp += x
			else:
				partsum+=int(temp)
				temp = ""
		print(partsum)
		msg_recv = f"{len(str(partsum)):<10}"+str(partsum)
		print(msg_recv)
		mini.send(msg_recv.encode("utf-8"))
		time.sleep(1)
	except:
		print("SENT BACK ALL THE SUMS ")
		break
