import socket
import select
import sys
import threading
import time

head_size = 10

server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)#Allows us to reconnect or reuse and address SOL - socket option level SO - socket option attribute selection and 1 sets it t o True

server.bind((socket.gethostname(),1024))
print("Listening for connections ....")
server.listen()
full_ar = ""
ar_size =0
global su
global x
su =0
x =0
clientsocket,addr = server.accept()	
def recv_msg(client):
	msg_head = client.recv(head_size)
	msglen = int(msg_head.decode("utf-8"))
	print(msglen)
	x = (client.recv(msglen+10)).decode("utf-8")
	print(x)
	print("Received {}".format(x))
	return(x)

def eachtime(string,su,conn):
	

	string = f"{len(string):<10}" + string
	conn.send(bytes(string.encode("utf-8")))
	t = int(recv_msg(conn))
	su+=t
	return(su)

	
	

def doo(m,full_ar):
	x =0
	su = 0
	print("Waiting to connect to the minions")
	conn,addr = server.accept()
	#for i in range(m):
	#	stri = ""
	##	print(2*x*int(ar_size/m))
	#	print(2*(x+1)*int(ar_size/m))
	#	if(i<(m-1)):
	#		stri = (full_ar[2*x*int(ar_size/m):(2*(x+1)*int(ar_size/m))])
	#	else:
	#		stri = (full_ar[2*x*int(ar_size/m):])
	#	x+=1
	stri = ""
	count = 0
	no = 0
	t=1
	for ele in full_ar :
		if(ele == ' '):
			count+= 1

	for ele in full_ar:
		if(ele != ' '):
			stri += ele
		else:
			no+=1
			if(t<m):
				if(no==t*int(count/m)):
					t+=1
					print(stri)
					su = eachtime(stri,su,conn)
					stri = ""
				else :
					stri += " "

			elif(t==m):
				if(no==count):
					print(stri)
					su = eachtime(stri,su,conn)

					stri = ""
				else:
					stri += " "
			else:
				stri += " "
			
	clientsocket.send(bytes(str(su).encode("utf-8")))

def clienttoserver():
	

	print("We are now connected to {}".format(addr))
	full_ar  = recv_msg(clientsocket)
	print(full_ar)
	m = int(input("Enter the number of minions you want to use : "))
	threading.Thread(target = lambda:doo(m,full_ar)).start()



clienttoserver()




	


